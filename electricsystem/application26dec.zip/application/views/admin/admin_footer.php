		<div class="footer">
			<h2>&copy; www.zoomrahul.com</h2>		
		</div>
		
	</div>
	<!--Container Ends Here-->

</body>
</html>