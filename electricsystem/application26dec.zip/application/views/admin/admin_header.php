<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?= link_tag('assets/css/admin_add_category.css'); ?>
</head>
<body>
	<!--Container Start Here -->
	<div class="container">
		<!--Header Wrapper Start Here-->
		<div class="header-wrapper">
			<!--Header Start Header-->
			<div class="header">
				<img src="<?= base_url(); ?>assets/images/elegant.png" class="header-image">
				<h4 class="header-title">Elegant Knight Fire</h4>
			</div>
			<!--Header Ends Here-->
		</div>
		<!--Header Wrapper End Here-->
