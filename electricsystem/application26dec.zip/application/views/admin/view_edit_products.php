<?php include "view_header.php"; ?>

<div>
	<?php if($errors = $this->session->flashdata('dashboard_category_success')): ?>
		<div class="alert-dashboard-category alert-dashboard-category-success">
			<span style="display: flex;justify-content: center;"><?= $errors; ?></span>
		</div>
	<?php endif; ?>

	<?php if($errors = $this->session->flashdata('dashboard_category_failed')): ?>
		<div class="alert-dashboard-category alert-dashboard-category-danger">
			<span style="display: flex;justify-content: center;"><?= $errors; ?></span>
		</div>
	<?php endif; ?>

</div>			

<div class="parent-container">

	<?php echo form_open_multipart('AdminController/editProduct', ['class'=> 'add-category']); ?>

		<?php if($errors = $this->session->flashdata('admin_category_success')): ?>
			<div class="alert-category alert-category-success">
				<?= $errors; ?>
			</div>
		<?php endif; ?>

		<?php if($errors = $this->session->flashdata('admin_category_failed')): ?>
			<div class="alert-category alert-category-danger">
				<?= $errors; ?>
			</div>
		<?php endif; ?>

		<h4 class="title"><strong>Product Name:</strong></h4>
		<?php echo form_input(['name' => 'product_name', 'placeholder' => 'Product Name', 'value' => set_value('product_name', $products -> product_name)]); ?>
		<span class="errors"><?php echo form_error('product_name'); ?></span>

		<h4 class="title"><strong>Product Description:</strong></h4>
		<?php 
			$data = array(
				'name'        => 'product_description',
				'value'       => set_value('product_description', $products -> product_description),
				'placeholder' => 'Product Description',
				'rows'        => '10',
				'cols'        => '10',
				'style'       => 'width:100%',
			);

			echo form_textarea($data); 

		?>
		<span class="errors"><?php echo form_error('product_description'); ?></span>

		<h4 class="title"><strong>Select Category Name:</strong></h4>
	
		<select class="selectOption" name="category_id">
			<?php foreach ($categories as $key => $value) { ?>
				<option value="<?= $value->category_id ?>" <?php if ($value-> category_id === $products-> category_id) {
					echo "selected";
				} ?>>
					<?= $value->category_name ?>
				</option>
				
			<?php } ?>
		</select>
		<span class="errors"><?php echo form_error('category_name'); ?></span>

		<h4 class="title"><strong>Product Image:</strong></h4>
		<?php echo form_upload(['name' => 'product_image']); ?>
		<span class="errors">
			<?php if ( isset( $upload_error ) ) {
				echo $upload_error;
			}
			?>
		</span>

		<div>
			<?php echo form_hidden('product_id', $products -> product_id); ?>

			<?php echo form_submit(['name' => 'submit', 'value' => 'Submit', 'class' => 'admin-button']); ?>
			<?php echo form_reset(['name' => 'reset', 'value' => 'Reset', 'class' => 'admin-cancel-button']); ?>
		</div>

	</form>

</div>			

<?php include "view_footer.php"; ?>