<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends MY_Controller {

	public function index()
	{
		$this->load->helper(array('url', 'html', 'form'));
		if ($this->session->userdata('user_id')){
			return redirect('AdminController/dashboard');
		} else {
			$this->load->view('users/view_login');
		}
	}

	public function login()
	{
		$this->load->helper(array('url', 'html', 'form'));
		$this->load->library('form_validation');
		
		//$this->form_validation->set_rules('email', 'Email', 'required|trim');
		//$this->form_validation->set_rules('password', 'Password', 'required|trim');
		/*$this->form_validation->set_error_delimiters('<div class="errors">', '</div>');*/

		if ($this->form_validation->run('admin_login_rules')) {

			$email = $this->input->post('email');
			$password = $this->input->post('password');

			$this->db->where(array('email' => $email, 'password' => md5($password)));
			$login_id = $this->db->get($this->table_users)->row()->user_id;
			$user_status = $this->db->get($this->table_users)->row()->user_status;

			if ($login_id) {
				if ($user_status == 'verified') {
					$this->session->set_userdata('user_id', $login_id);
					return redirect('AdminController/dashboard');
				} else {
					$this->session->set_flashdata('login_failed', 'Email is not verified.');
					redirect('LoginController');

				}
			} else {
				// authenticate failed
				// $this->load->view('users/view_invalid_login');

				$this->session->set_flashdata('login_failed', 'Invalid Email/Password.');
				redirect('LoginController');
			}
			

		}else {
			//echo "failed";
			//echo validation_errors();

			$this->load->view('users/view_login');

		}

	}

}
