<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminController extends MY_Controller {

	public function __construct()
    {
            parent::__construct();
			$this->load->helper(array('url', 'html', 'form'));
			$this->load->library(array('form_validation', 'upload'));
			$this->load->model('ArticlesModel', 'articles');
      		if (!$this->session->userdata('user_id')) {
				return redirect('LoginController');
			}

    }

    public function index()
    {
    	$this->dashboard();
    }

	public function dashboard()
	{

		$this->load->view('admin/view_dashboard');
	}

	public function profile()
	{
		$user_id = $this->session->userdata('user_id');
		$users = $this->db->select('*')->from($this->table_users)->where('user_id', $user_id)->get()->row();
		//$this->print($users);

		$this->load->view('admin/view_profile', ['user_detail' => $users]);
	}

	public function activityUser()
	{
		$user_id = $this->input->post('user_id');
		$users = array('user_status' => $this->input->post('user_status'));
		$user_updated = $this->db->where('user_id', $user_id)->update($this->table_users, $users);

		return $this->flash($user_updated, $this->input->post('profile_activity'), 'Something Error!!', 'AdminController/profile');

	}

	public function editUserProfile() {

		$user_id = $this->session->userdata('user_id');
		$user_detail = $this->db->select()
								 ->from($this->table_users)
								 ->where('user_id', $user_id)
								 ->get()
								 ->row();

		$this->load->view('admin/view_edit_profile', ['user_detail' => $user_detail]);
	}

	public function updateUserProfile() {
		$this->load->library('form_validation');
		if ($this->form_validation->run('add_category_rules')) {
			//$post = $this->input->post();
			//print_r($post); exit();
			//unset($post['submit']);
			
			$category = array('category_name' => $this->input->post('category_name'),'category_description' => $this->input->post('category_description'));
			$category_updated = $this->db->where('category_id', $category_id)->update($this->table_category, $category);

			return $this->flashMessage($category_updated, 'Category Updated...', 'Category Not Updated...');

		} else {
			$this->editUserProfile();
		}

	}

	public function products()
	{
		$categories = $this->db->select('*')
							 ->from($this->table_category)
							 ->get()
							 ->result();
		
		$this->load->view('admin/view_products', ['categories' => $categories]);
	}

	public function notification()
	{

		$this->load->view('admin/view_notification');
	}

	public function category()
	{
		$this->load->library('pagination');

		$user_id = $this->session->userdata('user_id');
		$category = $this->db->select()
							 ->from($this->table_category)
							 ->where('user_id', $user_id)
							 ->get();
		$number_articles = $category->num_rows();

		$config = array();
		$config['base_url'] = base_url('AdminController/category');
		$config['per_page'] = 3;
		$config['total_rows'] = $number_articles;
		$config['num_links'] = $number_articles;
		$config['full_tag_open']= "<div class='pagination'>";
		$config['full_tag_close']= "</div>";
		$config['prev_link']= "Previous";
		$config['next_link']= "Next";
		/*$config['next_tag_open']= "<a>";
		$config['next_tag_close']= "</a>";
		$config['pre_tag_open']= "<a>";
		$config['pre_tag_close']= "</a>";
		$config['num_tag_open']= "<a>";
		$config['num_tag_close']= "</a>";*/
		$config['cur_tag_open']= "<a class='active'>";
		$config['cur_tag_close']= "</a>";

		//$this->print($config);
		$this->pagination->initialize($config);

		$limit = $config['per_page'];
		$offset = $this->uri->segment(3);

		$categories = $this->db->select()
							 ->from($this->table_category)
							 ->where('user_id', $user_id)
							 ->order_by('category_id', 'desc')
							 ->limit($limit, $offset)
							 ->get()
							 ->result();

		$this->load->view('admin/view_category', ['categories' => $categories]);
	}

	public function logout()
	{
		$this->session->unset_userdata('user_id');
		return redirect('LoginController');
	}

	public function addCategory()
	{
		$this->load->view('admin/view_add_category');

	}

	public function createCategory()
	{
		$config = array();
		$config['upload_path']          = './uploads/category/';
		$config['allowed_types']        = 'gif|jpg|png|jpeg';
		/*$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;*/


		$this->load->library('upload', $config);
		$this->upload->initialize($config);

        /*if ( ! $this->upload->do_upload())
        {
                $error = array('error' => $this->upload->display_errors());
                print_r($error);
        }
        else
        {
                $arr_image = array('upload_data' => $this->upload->data());
                print_r($arr_image);
        }*/


		$form_validation = $this->form_validation->run('add_category_rules');
		$uploads = $this->upload->do_upload('userfile');

		if ($form_validation && $uploads) {
			//$post = $this->input->post();
			//print_r($post); exit();
			//unset($post['submit']);

			$image_data = $this->upload->data();
			
			$data = array();
			$data['category_name'] = $this->input->post('category_name');
			$data['category_description'] = $this->input->post('category_description');
			$data['category_image'] = base_url()."uploads/category/".$image_data['raw_name'].$image_data['file_ext'];
			$data['user_id'] = $this->input->post('user_id');
			$data['category_status'] = '0';
			$data['category_created_on'] = $this->input->post('created_at');

			$articles = $this->db->insert($this->table_category, $data);
			
			return $this->flash($articles, '!! Category added !!', 'Category not added...', 'AdminController/category');

		} else {
			$upload_error = $this->upload->display_errors();
			$this->load->view('admin/view_add_category', compact('upload_error'));
		}
		
	}


	public function editCategory()
	{
		if ($_POST) {
			$category_id = $this->input->post('category_id');
			$this->session->set_userdata('category_id', $category_id);

			//$post = $this->input->post();
			//print_r($post); exit();
		} else {
			$category_id = $this->session->userdata('category_id');
		}

		$category = $this->db->select()
								 ->from($this->table_category)
								 ->where('category_id', $category_id)
								 ->get()
								 ->row();
		//echo "<pre>"; print_r($category);

		$this->load->view('admin/view_edit_category', ['category' => $category]);
	}

	public function updateCategory($category_id)
	{
		$this->load->library('form_validation');
		if ($this->form_validation->run('add_category_rules')) {
			//$post = $this->input->post();
			//print_r($post); exit();
			//unset($post['submit']);
			
			$category = array('category_name' => $this->input->post('category_name'),'category_description' => $this->input->post('category_description'));
			$category_updated = $this->db->where('category_id', $category_id)->update($this->table_category, $category);

			return $this->flash($category_updated, 'Category Updated...', 'Category Not Updated Error!!', 'AdminController/category');

		} else {
			$this->editCategory();
		}
		
	}

	public function deleteCategory()
	{
		$delete_category = $this->input->post();
		//echo "<pre>"; print_r($delete_category); exit();

		$category_id = $delete_category['category_id'];
		$category_deleted = $this->db->delete($this->table_category, ['category_id' => $category_id]);

		return $this->flashMessage($category_deleted, 'Category Deleted...', 'Category Not Deleted...');

	}

	public function activeCategory()
	{
		$active_category = $this->input->post();
		//echo "<pre>"; print_r($active_category); exit();

		$category_id = $active_category['category_id'];
		$category = array('category_status' => $this->input->post('category_status'));
		$category_updated = $this->db->where('category_id', $category_id)->update($this->table_category, $category);

		return $this->flashMessage($category_updated, $this->input->post('category_activity'), 'Something Error!!');

	}


	/************************************************************************************************************/

	public function createProduct()
	{
		$config = array();
		$config['upload_path']          = './uploads/category/';
		$config['allowed_types']        = 'gif|jpg|png|jpeg';
		/*$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;*/


		$this->load->library('upload', $config);
		$this->upload->initialize($config);

        /*if ( ! $this->upload->do_upload())
        {
                $error = array('error' => $this->upload->display_errors());
                print_r($error);
        }
        else
        {
                $arr_image = array('upload_data' => $this->upload->data());
                print_r($arr_image);
        }*/


		$form_validation = $this->form_validation->run('add_category_rules');
		$uploads = $this->upload->do_upload('userfile');

		if ($form_validation && $uploads) {
			//$post = $this->input->post();
			//print_r($post); exit();
			//unset($post['submit']);

			$image_data = $this->upload->data();
			
			$data = array();
			$data['category_name'] = $this->input->post('category_name');
			$data['category_description'] = $this->input->post('category_description');
			$data['category_image'] = base_url()."uploads/category/".$image_data['raw_name'].$image_data['file_ext'];
			$data['user_id'] = $this->input->post('user_id');
			$data['category_status'] = '0';
			$data['category_created_on'] = $this->input->post('created_at');

			$articles = $this->db->insert($this->table_category, $data);
			
			return $this->flash($articles, '!! Category added !!', 'Category not added...', 'AdminController/category');

		} else {
			$upload_error = $this->upload->display_errors();
			$this->load->view('admin/view_add_category', compact('upload_error'));
		}
		
	}

	/************************************************************************************************************/

	public function flashMessage($isSuccessful = false, $successfulMessage = '', $failureMessage = '')
	{
		if ($isSuccessful) {
			$this->session->set_flashdata('dashboard_category_success', $successfulMessage);
			
		} else {
			$this->session->set_flashdata('dashboard_category_success', $failureMessage);
			
		}
		
		return redirect('AdminController/dashboard');
	}
	
	public function flash($isSuccessful = false, $successfulMessage = '', $failureMessage = '', $page = '')
	{
		if ($isSuccessful) {
			$this->session->set_flashdata('dashboard_category_success', $successfulMessage);
			
		} else {
			$this->session->set_flashdata('dashboard_category_success', $failureMessage);
			
		}
		
		return redirect($page);
	}

}
