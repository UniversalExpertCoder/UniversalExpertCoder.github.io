<?php include 'view_header.php'; ?>

<div class="parent-container">
	<?php echo form_open("AdminController/updateCategory/{$category -> category_id}", ['class'=> 'add-category']); ?>

		<!-- <?php echo form_hidden('user_id', $this->session->userdata('user_id')); ?> -->

		<?php if($errors = $this->session->flashdata('admin_category_success')): ?>
			<div class="alert-category alert-category-success">
				<?= $errors; ?>
			</div>
		<?php endif; ?>

		<?php if($errors = $this->session->flashdata('admin_category_failed')): ?>
			<div class="alert-category alert-category-danger">
				<?= $errors; ?>
			</div>
		<?php endif; ?>

		<h4 class="title"><strong>Category Title:</strong></h4>
		<?php echo form_input(['name' => 'category_name', 'placeholder' => 'Category Title', 'value' => set_value('category_name', $category -> category_name)]); ?>
		<span class="errors"><?php echo form_error('category_name'); ?></span>

		<h4 class="title"><strong>Category Body:</strong></h4>
		<?php echo form_textarea(['name' => 'category_description', 'placeholder' => 'Category Body', 'value' => set_value('category_description', $category -> category_description)]); ?>
		<span class="errors"><?php echo form_error('category_description'); ?></span>

		<h4 class="title"><strong>Category Image:</strong></h4>
		<?php echo form_upload(['name' => 'userfile']); ?>
		<span class="errors">
			<?php if ( isset( $upload_error ) ) {
				echo $upload_error;
			}
			?>
		</span>

		<div>
			<?php echo form_hidden('category_id', $category -> category_id); ?>
			<?php echo form_submit(['name' => 'submit', 'value' => 'Submit', 'class' => 'admin-button']); ?>
			<?php echo form_reset(['name' => 'reset', 'value' => 'Reset', 'class' => 'admin-cancel-button']); ?>
		</div>

	</form>

</div>

<!-- <?php echo validation_errors(); ?> -->
<?php include 'view_footer.php'; ?>